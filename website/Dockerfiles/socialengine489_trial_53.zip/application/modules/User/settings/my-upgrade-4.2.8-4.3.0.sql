
ALTER TABLE `engine4_user_fields_values`
ADD COLUMN `privacy` varchar(64) default NULL;
