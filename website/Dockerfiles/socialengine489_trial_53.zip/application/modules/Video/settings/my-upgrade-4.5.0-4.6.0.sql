ALTER TABLE `engine4_video_videos`
ADD COLUMN `rotation` smallint unsigned NOT NULL DEFAULT '0';
